﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skat
{
    public class Afgift
    {
        
        public int BilAfgift(int pris)
        {
            
            double bilAfgift;

            //Først tjekker jeg om prisen er mindre end 0, og hvis den er kaster jeg en exception
            if (pris < 0)
            {
                throw new ArgumentException("Pris må ikke være mindre end 0");
            }
            //Hvis prisen er mindre end eller lig med 200000, bruger jeg formlen: pris *0.85
            if (pris <= 200000)
            {
                bilAfgift = pris * 0.85;
               
            }
            //Hvis prisen er større end 200000 bruges formlen: pris * 1.50 - 130000.
            else
            {
                bilAfgift = (pris * 1.50) - 130000;
               
            }

            //Her konverterer jeg min double bilAfgift til en int afgift, da metoden skal returnere en int
            int afgift = Convert.ToInt32(bilAfgift);

            //Her returneres afgiften på den pågældende bil
            return afgift;
        }

        public int ElBilAfgift(int pris)
        {
            double elbilAfgift;
            //Først tjekker jeg om prisen er mindre end 0, og hvis den er kaster jeg en exception
            if (pris < 0)
            {
               throw new ArgumentException("Pris må ikke være mindre end 0");
            }
            //Hvis prisen er mindre end eller lig med 200000, bruger jeg formlen: pris *0.85
            //efterfølgende tager jeg elbilAfgift og ganger med 0.20, da man i danmark kun betaler 20% af afgiften på en elbil
            if (pris <= 200000)
            {
                elbilAfgift = pris * 0.85;
                elbilAfgift = elbilAfgift * 0.20;
            }
            //Hvis prisen er større end 200000 bruges formlen: pris * 1.50 - 130000.
            //efterfølgende tager jeg elbilAfgift og ganger med 0.20, da man i danmark kun betaler 20% af afgiften på en elbil
            else
            {
                elbilAfgift = (pris * 1.50) - 130000;
                elbilAfgift = elbilAfgift * 0.20;
                
            }

            //Her konverterer jeg min double elbilAfgift til en int afgift, da metoden skal returnere en int
            int afgift = Convert.ToInt32(elbilAfgift);

            // Her returneres afgiften på den pågældende elbil
            return afgift;
        }
    }





}
