﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using Skat;

namespace TCPSkatServer
{
    class BeregnAfgift
    {
        private TcpClient _connectionSocket;
       

        public BeregnAfgift(TcpClient connectionSocket)
        {
            _connectionSocket = connectionSocket;
        }

        public void DoIt()
        {
            Stream ns = _connectionSocket.GetStream();
            StreamWriter sw = new StreamWriter(ns);
            StreamReader sr = new StreamReader(ns);
            sw.AutoFlush = true;
            Afgift afgift = new Afgift();
            

            while (true)
            {
                string message = sr.ReadLine();
                Console.WriteLine("Klient: " + message);

                if (message == "Bil" || message == "bil")
                {
                    string answer = "Indtast prisen på bilen";
                    sw.WriteLine(answer);

                    message = sr.ReadLine();
                    Console.WriteLine("Klient: " + message);

                    int pris = Convert.ToInt32(message);

                    answer = "Afgiften på bilen er: " + afgift.BilAfgift(pris).ToString();
                    sw.WriteLine(answer);
                }

                else if (message == "Elbil" || message == "elbil")
                {
                    string answer = "Indtast prisen på elbilen";
                    sw.WriteLine(answer);

                    message = sr.ReadLine();
                    Console.WriteLine("Klient: " + message);

                    int pris = Convert.ToInt32(message);

                    answer = "Afgiften på elbilen er: " + afgift.ElBilAfgift(pris).ToString();
                    sw.WriteLine(answer);
                }
                else
                {
                    string answer = "Venligst indtastet bilens type";
                    sw.WriteLine(answer);
                }
            }
        }
    }
}
