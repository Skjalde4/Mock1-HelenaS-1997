using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Skat;

namespace TestSkat
{
    [TestClass]
    public class UnitTest1
    {
        Afgift afgift = new Afgift();

        [TestMethod]
        public void TestBilAfgiftUnder200000()
        {
            int pris = 180000;
            int forventetResultat = 153000;


            int faktiskeResultat = afgift.BilAfgift(pris);


            Assert.AreEqual(forventetResultat, faktiskeResultat);
        }

        [TestMethod]
        public void TestBilAfgiftOver200000()
        {
            int pris = 250000;
            int forventetResultat = 245000;


            int faktiskeResultat = afgift.BilAfgift(pris);


            Assert.AreEqual(forventetResultat, faktiskeResultat);
        }

        [TestMethod]
        public void TestBilAfgiftNegativ()
        {
            int pris = -10000;


            try
            {
                afgift.BilAfgift(pris);
            }
            catch (Exception e)
            {
                Assert.AreEqual("Pris m� ikke v�re mindre end 0", e.Message);
            }
        }

        [TestMethod]
        public void TestElbilAfgiftUnder200000()
        {
            int pris = 180000;
            int forventetResultat = 30600;

            int faktiskeResultat = afgift.ElBilAfgift(pris);


            Assert.AreEqual(forventetResultat, faktiskeResultat);
        }

        [TestMethod]
        public void TestElbilAfgiftOver200000()
        {
            int pris = 250000;
            int forventetResultat = 49000;

            int faktiskeResultat = afgift.ElBilAfgift(pris);

            Assert.AreEqual(forventetResultat, faktiskeResultat);
        }

        [TestMethod]
        public void TestElbilAfgiftNegativ()
        {
            int pris = -10000;

            try
            {
                afgift.ElBilAfgift(pris);

            }
            catch (Exception e)
            {
                Assert.AreEqual("Pris m� ikke v�re mindre end 0", e.Message);
            }
        }
    }
}
